<?php

namespace Drupal\corso\Annotation;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\Annotation\FieldWidget;
use Drupal\Core\Form\FormStateInterface;

/**
 * Widget per la presentazione delle province.
 *
 * @Annotation
 */
class ProvincesWidget extends FieldWidget
{
}
