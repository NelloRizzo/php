<?php

namespace Drupal\corso\provinces\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\corso\ProvincesWidgetPluginManager;

/**
 * Controller per il test del plugin.
 */
class ProvincesWidgetController extends ControllerBase
{

  /**
   * Il plugin manager.
   *
   * @var \Drupal\corso\ProvincesWidgetPluginManager
   */
  protected $provincesManager;

  public function __construct(ProvincesWidgetPluginManager $manager)
  {
    $this->provincesManager = $manager;
  }

  public function description()
  {
    $p = [];
    $p['intro'] = "Utilizzo del mio plugin";

    $plugin = $this->provincesManager->getDefinitions()[0];

    $p['my-plugin'] = ['#items' => $plugin->buildWidget()];
    return $p;
  }
}
