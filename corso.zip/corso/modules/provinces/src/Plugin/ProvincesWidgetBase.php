<?php

namespace Drupal\corso;

use Drupal\Core\Field\WidgetBase;

abstract class ProvincesWidgetBase extends WidgetBase implements ProvincesWidgetInterface{

  abstract public function getProvinces();
}
