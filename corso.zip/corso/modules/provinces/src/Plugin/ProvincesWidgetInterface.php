<?php

namespace Drupal\corso;

/**
 * Interfaccia per il plugin di gestione delle Province Italiane.
 */
interface ProvincesWidgetInterface {
  /**
   * Restituisce l'elenco delle province italiane.
   *
   * @return array l'elenco delle province.
   */
  public function getProvinces();
}
