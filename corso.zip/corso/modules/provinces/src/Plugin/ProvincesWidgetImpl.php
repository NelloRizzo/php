<?php

namespace Drupal\corso;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implementazione standard di un provinces widget.
 *
 * @ProvincesWidget(id = 'standard_provinces')
 */
class ProvincesWidgetImpl extends ProvincesWidgetBase {
  public function getProvinces(){
    return ['AO', 'TO', 'MI'];
  }

  public function formElement(FieldItemListInterface $items, $d, array $e, array &$f, FormStateInterface $state){
    $e += [
      '#type' => 'select',
      '#options' => $this->getProvinces()
    ];
    return ['value' => $e];
  }
}
