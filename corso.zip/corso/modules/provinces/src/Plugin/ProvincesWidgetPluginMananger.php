<?php

namespace Drupal\corso;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\corso\Annotation\ProvincesWidget;

/**
 * Plugin managegr per il ProvincesWidet.
 */
class ProvincesWidgetPluginManager extends DefaultPluginManager {

  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin', $namespaces, $module_handler, ProvincesWidgetInterface::class, ProvincesWidget::class);
  }
}
