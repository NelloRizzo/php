<?php

namespace Drupal\form_api_example\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Url;

/**
 * Implements InputDemo form controller.
 *
 * This example demonstrates the different input elements that are used to
 * collect data in a form.
 */
class InputDemo extends FormBase
{

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
    $cities = new CitiesService();

    $form['description'] = [
      '#type' => 'item',
      '#markup' => $this->t('Consente di inserire i dati anagrafici per il calcolo del codice fiscale.'),
    ];

    $form['first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Nome'),
      '#size' => 60,
      '#maxlength' => 60,
      '#required' => TRUE,
      '#description' => $this->t('Il nome della persona'),
    ];
    $form['last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Cognome'),
      '#size' => 60,
      '#required' => TRUE,
      '#maxlength' => 60,
      '#description' => $this->t('Il cognome della persona'),
    ];

    $form['birthday'] = [
      '#type' => 'date',
      '#title' => $this->t('Data di nascita'),
      '#default_value' => '1900-01-01',
      '#required' => TRUE,
      '#description' => 'Data di nascita della persona',
    ];

    $form['gender'] = [
      '#type' => 'select',
      '#title' => $this->t('Sesso'),
      '#options' => [
        'm' => $this->t('Uomo'),
        'f' => $this->t('Donna'),
      ],
      '#required' => TRUE,
      '#empty_option' => $this->t('-----'),
      '#description' => $this->t('Sesso della persona'),
    ];

    //    $form['birth_city'] = [
//      '#type' => 'textfield',
//      '#title' => $this->t('Città di nascita'),
//      '#size' => 4,
//      '#maxlength' => 6,
//      '#minlength' => 4,
//      '#required' => TRUE,
//      '#description' => $this->t('Il codice catastale del comune di nascita'),
//    ];

    foreach ($cities->getCities() as $k => $v) {
      $options["{$k}"] = $v->denominazione;
    }

    $form['birth_city'] = [
      '#type' => 'select',
      '#title' => $this->t('Città di nascita'),
      '#options' => $options,
      '#description' => $this->t('Selezionare la città di nascita dall\'elenco'),
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Calcola Codice Fiscale'),
      '#description' => $this->t('Invia i dati al server e calcola il codice fiscale relativo'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId()
  {
    return 'form_api_example_input_demo_form';
  }

  private FiscalCodeServiceInterface $service;
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    $first_name = $form_state->getValue('first_name');
    $last_name = $form_state->getValue('last_name');
    $birthday = $form_state->getValue('birthday');
    $gender = $form_state->getValue('gender');
    $birth_city = $form_state->getValue('birth_city');

    $data = new PersonalData(
      $first_name,
      $last_name,
      new \DateTimeImmutable($birthday),
      $gender == 'm' ? Gender::Male : Gender::Female,
      $birth_city
    );
    $this->service = new FiscalCodeService();
    $fc = $this->service->calculateFiscalCode($data);

    $this->messenger()->addMessage("$first_name $last_name ($birthday) $gender $birth_city = $fc");
  }

}