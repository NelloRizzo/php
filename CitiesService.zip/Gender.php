<?php

namespace Drupal\form_api_example\Form;

enum Gender {
    case Male;
    case Female;
}