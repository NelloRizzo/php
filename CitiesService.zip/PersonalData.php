<?php

namespace Drupal\form_api_example\Form;

class PersonalData
{
    public string $firstName;
    public string $lastName;
    public \DateTimeImmutable $birthday;
    public Gender $gender; 
    public string $birth_city;

    public function __construct(string $fn, string $ln, \DateTimeImmutable $bd, Gender $ge, string $bc)
    {
        $this->firstName = $fn;
        $this->lastName = $ln;
        $this->birth_city = $bc;
        $this->gender = $ge;
        $this->birthday = $bd;
    }
}