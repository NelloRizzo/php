<?php

namespace Drupal\form_api_example\Form;

use Drupal\mysql\Driver\Database\mysql\Connection;

class CitiesService implements CitiesServiceInterface
{
    public function getById(int $id): array
    {
        \Drupal\Core\Database\Database::setActiveConnection('cities', 'default');
        $connection = \Drupal\Core\Database\Database::getConnection();
        $q = $connection->query('SELECT * FROM {comuni} WHERE id = :id', [":id" => $id]);
        return $q->fetchAssoc();
    }
    public function getProvinces(): array
    {
        \Drupal\Core\Database\Database::setActiveConnection('cities', 'default');
        $connection = \Drupal\Core\Database\Database::getConnection();
        $q = $connection->query('SELECT DISTINCT sigla FROM {comuni} ORDER BY 1');
        return $q->fetchAllAssoc('sigla');
    }
    public function getCitiesByProvince(string $province): array
    {
        \Drupal\Core\Database\Database::setActiveConnection('cities', 'default');
        $connection = \Drupal\Core\Database\Database::getConnection();
        $q = $connection->query('SELECT * FROM {comuni} WHERE sigla = :sigla ORDER BY nome', [':sigla' => $province]);
        return $q->fetchAllAssoc('id');
    }

    public function getCities(): array
    {
        \Drupal\Core\Database\Database::setActiveConnection('cities', 'default');
        $connection = \Drupal\Core\Database\Database::getConnection();
        $q = $connection->query("SELECT id, nome || ' (' || sigla || ')' denominazione FROM {comuni}  ORDER BY nome");
        return $q->fetchAllAssoc('id');
    }

}