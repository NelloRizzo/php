<?php

namespace Drupal\form_api_example\Form;

interface CitiesServiceInterface
{
    public function getById(int $id): array;
    public function getProvinces(): array;
    public function getCitiesByProvince(string $province): array;
}