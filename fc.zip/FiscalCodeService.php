<?php
namespace Drupal\form_api_example\Form;

class FiscalCodeService implements FiscalCodeServiceInterface
{
    public function calculateFiscalCode(PersonalData $input): string
    {
        $fc = "XXXXXX00X00X000X";

        return $fc;
    }
}