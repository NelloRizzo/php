<?php

namespace Drupal\form_api_example\Form;

interface FiscalCodeServiceInterface
{
    public function calculateFiscalCode(PersonalData $input): string;
}